# Monitoring Stack (Prometheus + Grafana + Node Exporter + Alertmanager)

## Quick Start
```bash
docker compose up -d
```

Services:
- Prometheus: http://localhost:9090
- Alertmanager: http://localhost:9093
- Grafana: http://localhost:3000 (admin / admin)

In Grafana, import a dashboard such as "Node Exporter Full" (ID: 1860).

## Notes
- Node Exporter mounts /proc, /sys, and / for host metrics.
- Configure real notifications in `alertmanager/alertmanager.yml` (Slack or email).
- Reload Prometheus after alert rule changes:
  ```bash
  docker compose exec prometheus kill -HUP 1
  ```
